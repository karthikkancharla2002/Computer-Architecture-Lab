package processor.pipeline;

import generic.Statistics;
import processor.Processor;
import generic.Simulator;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	public String Extender(String str){			// Converts to 32 bit string

		if(str.substring(0,1).equals("0")){
			while(str.length() < 32){
				str =  '0'+ str ;
			}
		}else if(str.substring(0,1).equals("1")){
			while(str.length() < 32){
				str =  '1'+ str ;
			}
		}
		return str;

	}
	static String twoscomplement(StringBuffer str)
	{
		int n = str.length();

		// Traverse the string to get first '1' from
		// the last of string
		int i;
		for (i = n-1 ; i >= 0 ; i--)
			if (str.charAt(i) == '1')
				break;

		// If there exists no '1' concat 1 at the
		// starting of string
		if (i == -1)
			return "1" + str;

		// Continue traversal after the position of
		// first '1'
		for (int k = i-1 ; k >= 0; k--)
		{
			//Just flip the values
			if (str.charAt(k) == '1')
				str.replace(k, k+1, "0");
			else
				str.replace(k, k+1, "1");
		}

		// return the modified string
		return str.toString();
	}

	public String intToStr(int value){
		String binary_str = "";
		if(value >= 0){
			binary_str = "0"+ Integer.toString(value,2);
		}else{
			String rrr = Integer.toString(value,2).substring(1);
			binary_str = "1"+ twoscomplement(new StringBuffer(rrr));
		}
		return binary_str;
	}

	public int strToint(String str){

		if(str.substring(0,1).equals("0")){
			return Integer.parseInt(str,2);
		}else if(str.substring(0,1).equals("1")){
			String two_c = twoscomplement(new StringBuffer(str));
			return -1* Integer.parseInt(two_c,2);
		}else {
			return 0;
		}

	}

	
	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{	Statistics.setNumberOfCycles(Statistics.getNumberOfCycles()+1);
			String op2;
			String op1, imm;

			int inst = IF_OF_Latch.getInstruction();

			String inst_str = Extender(intToStr(inst));


			String opcode = inst_str.substring(0,5);

			if(opcode.equals("11101")){
				Simulator.setSimulationComplete(true); // Setting for 'end'
				return;
			}

			int PC = containingProcessor.getRegisterFile().getProgramCounter();
			int offset = strToint(inst_str.substring(15));	// By Default, we check for R2I Type
			if(opcode.equals("11000")){	 // jmp is RI Type
				offset = strToint(inst_str.substring(10));
			}

			imm = inst_str.substring(15);
			imm = Extender(imm);

			op2 = intToStr(containingProcessor.getRegisterFile().getValue(Integer.parseInt(inst_str.substring(10,15),2)));

			op1 = intToStr(containingProcessor.getRegisterFile().getValue(Integer.parseInt(inst_str.substring(5,10),2)));

			if(opcode.equals("11000")){ //for jump RI type
				op2 = intToStr(containingProcessor.getRegisterFile().getValue(Integer.parseInt(inst_str.substring(5,10),2)));
			}

			op1 =  Extender(op1);
			op2 = Extender(op2);
			int branchTarget = PC + offset-1;

			OF_EX_Latch.setInstruction(inst_str);
			OF_EX_Latch.setop1(op1);
			OF_EX_Latch.setop2(op2);
			OF_EX_Latch.setimm(imm);
			OF_EX_Latch.setBranchTarget(branchTarget);
			
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}
