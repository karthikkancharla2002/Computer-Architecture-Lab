package infiltrator;

import java.util.Random;
import java.util.ArrayList;

public class Infiltrator {
	public int x = 0;
	public int y = 0;
	int w = 0;
	int h = 0;
	
	public int moveInfiltrator() {
		int noOfMoves = 8;
		ArrayList<String> possibleMoves = new ArrayList<String>();
		
		if(x == 0 && y == 0) {
			possibleMoves.add("E");
			possibleMoves.add("SE");
			possibleMoves.add("S");
		}else if(x == 0 && y == w-1) {
			possibleMoves.add("N");
			possibleMoves.add("NE");
			possibleMoves.add("E");
		}else if(x == h-1 && y == 0) {
			possibleMoves.add("W");
			possibleMoves.add("SW");
			possibleMoves.add("S");
		}else if(x == h-1 && y == w-1) {
			possibleMoves.add("N");
			possibleMoves.add("NW");
			possibleMoves.add("W");
		}else if(x == 0) {
			possibleMoves.add("N");
			possibleMoves.add("NE");
			possibleMoves.add("E");
			possibleMoves.add("SE");
			possibleMoves.add("S");
		}else if(x == h-1) {
			possibleMoves.add("N");
			possibleMoves.add("NW");
			possibleMoves.add("W");
			possibleMoves.add("SW");
			possibleMoves.add("S");
		}else if(y == 0) {
			possibleMoves.add("E");
			possibleMoves.add("SE");
			possibleMoves.add("S");
			possibleMoves.add("SW");
			possibleMoves.add("W");
		}else if(y == w-1) {
			possibleMoves.add("E");
			possibleMoves.add("NE");
			possibleMoves.add("N");
			possibleMoves.add("NW");
			possibleMoves.add("W");
		}else {
			possibleMoves.add("N");
			possibleMoves.add("NE");
			possibleMoves.add("E");
			possibleMoves.add("SE");
			possibleMoves.add("S");
			possibleMoves.add("SW");
			possibleMoves.add("W");
			possibleMoves.add("NW");
		}
		
		if(x == 0 ||  x == h-1) {
			if(y == 0 || y == w-1) {	
				noOfMoves = 3;
			}else{
				noOfMoves = 5;
			}
		}else {
			if(y == 0 || y == w-1) {
				noOfMoves = 5;
			}else{
				noOfMoves = 8;
			}
		}
		
		Random r = new Random();
        int p  =  r.nextInt(noOfMoves+1);
        
        if(p> 0) {
        	System.out.println(possibleMoves.get(p-1));
        switch(possibleMoves.get(p-1)) {
        case "N":
        	x = x;
        	y = y-1;
        	break;
        case "NE":
        	x = x+1;
        	y = y-1;
        	break;
        case "E":
        	x = x+1;
        	y = y;
        	break;
        case "SE":
        	x = x+1;
        	y = y+1;
        	break;
        case "S":
        	x = x;
        	y = y+1;
        	break;
        case "SW":
        	x = x-1;
        	y = y+1;
        	break;
        case "W":
        	x = x-1;
        	y = y;
        	break;
        case "NW":
        	x = x-1;
        	y = y-1;
        	break;
        }}
        return p;
	}
	
	public Infiltrator(int temp_w, int temp_h) {
		w = temp_w;
		h = temp_h;
		Random r = new Random();
        x =  r.nextInt(h + 1);
	}

}
