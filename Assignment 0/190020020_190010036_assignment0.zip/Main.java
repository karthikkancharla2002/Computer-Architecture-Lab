import sensors.Sensors;
import infiltrator.Infiltrator;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
  public static void main(String[] args) {
	  int w = 5;
	  int h = 1000; 
	  double prob = 0.2;
	  double probs[]= {0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9};
	  int widths[] = {5,10,50,100};
	  
	    try (PrintWriter writer = new PrintWriter(new File("test.csv"))) {
	    	StringBuilder sb = new StringBuilder();
	    	
	    	for(int j=0;j<widths.length;j++)
	    	{
	    		double avgtime=0;
	    		double wincount=0;
	    		double lostcount=0;
	    		double wintime=0;
	    		double losttime=0;
			  	//prob=probs[j];
	    		w=widths[j];
			  	//sb.append(prob);
	    		sb.append(w);
				sb.append(' ');
			    Sensors sensors = new Sensors(w, prob, h);
			    
			    Infiltrator inf = new Infiltrator(w, h);

			    int t = 0;
	        
	        System.out.println("done!");

	      for(int i=0;i<1000;i++)
	      {
	    	  t=0;
			    while(true) {
			    	int isMove = 0;
			    	sensors.changeSensorValues();
			    	int init_x = inf.x;
			    	int init_y = inf.y;
			    	isMove = inf.moveInfiltrator();
			    	
			    	if(isMove > 0) {
			    		if(sensors.sensorValues[init_y][init_x] == 1) {
			    			System.out.println("Found Init");
			    			lostcount++;
			    			losttime+=t;
			    			break;
			    		} else if (sensors.sensorValues[inf.y][inf.x] == 1) {
			    			System.out.println("Found Dest");
			    			lostcount++;
			    			losttime+=t;
			    			break;
			    		}else if(inf.y == w-1) {
			    			System.out.println("Won ");
			    			wincount++;
			    			wintime+=t;
			    			break;
			    		}
			    	}
			    	t+=10;
			    }
		   }
	      	avgtime+=t;
		    sb.append(wincount/1000);
			sb.append('\n');
		    System.out.println(t);
		    
		    }
		    	writer.write(sb.toString());
		    }
		    
		     catch (FileNotFoundException e) {
		        System.out.println(e.getMessage());
		      }
	  
	  
	  
	  
	  

  }
}