from os import X_OK
import matplotlib.pyplot as plt
import numpy as np
import csv

filename = "WidthvsWinProb.csv"

xpoints=[]
ypoints=[]

with open(filename, 'r') as csvfile:
    # creating a csv reader object
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        a,b=row[0].split()
        b=float(b)
        b=round(b,5)
        xpoints.append(a)
        ypoints.append(b)



plt.plot(xpoints, ypoints)
plt.savefig(str(filename)+".png")
