package sensors;

public class Sensors {
	double prob = 0;
	public int[][] sensorValues;
	int w = 0;
	int h = 0;
	
	public void changeSensorValues() {
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				if(Math.random() >= prob) {
					sensorValues[i][j] =0;
				}else {
					sensorValues[i][j] =1;
				}
				
				
		      }
	      }
	  }
	
	public Sensors(int temp_w, double d, int temp_h){
		w = temp_w;
		h = temp_h;
		sensorValues = new int [w][h];
		prob = d;
		
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				sensorValues[i][j] = 0;
		      }
	      }
		
		changeSensorValues();
		
		
	}

	

}
