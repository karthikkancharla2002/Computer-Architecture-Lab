package generic;

import java.io.FileInputStream;
import generic.Operand.OperandType;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.lang.Class;
import java.util.ArrayList;

public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	static ArrayList<Instruction.OperationType> instructionsList = new ArrayList<Instruction.OperationType>() {
		{
			add(Instruction.OperationType.add);
			add(Instruction.OperationType.addi);
			add(Instruction.OperationType.sub);
			add(Instruction.OperationType.subi);
			add(Instruction.OperationType.mul);
			add(Instruction.OperationType.muli);
			add(Instruction.OperationType.div);
			add(Instruction.OperationType.divi);
			add(Instruction.OperationType.and);
			add(Instruction.OperationType.andi);
			add(Instruction.OperationType.or);
			add(Instruction.OperationType.ori);
			add(Instruction.OperationType.xor);
			add(Instruction.OperationType.xori);
			add(Instruction.OperationType.slt);
			add(Instruction.OperationType.slti);
			add(Instruction.OperationType.sll);
			add(Instruction.OperationType.slli);
			add(Instruction.OperationType.srl);
			add(Instruction.OperationType.srli);
			add(Instruction.OperationType.sra);
			add(Instruction.OperationType.srai);
			add(Instruction.OperationType.load);
			add(Instruction.OperationType.store);
			add(Instruction.OperationType.jmp);
			add(Instruction.OperationType.beq);
			add(Instruction.OperationType.bne);
			add(Instruction.OperationType.blt);
			add(Instruction.OperationType.bgt);
			add(Instruction.OperationType.end);
		}
	};
	public static void setupSimulation(String assemblyProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	public static void assemble(String objectProgramFile)
	{
		try{
			FileOutputStream file = new FileOutputStream(objectProgramFile);
			BufferedOutputStream bfile = new BufferedOutputStream(file);


			byte[] addressCode = ByteBuffer.allocate(4).putInt(ParsedProgram.firstCodeAddress).array();
			bfile.write(addressCode);


			for (int value: ParsedProgram.data) {
				byte[] dataValue = ByteBuffer.allocate(4).putInt(value).array();
				bfile.write(dataValue);
			}
			for(Instruction inst: ParsedProgram.code){
//				System.out.print("inst:    ");
//				System.out.print(inst.getClass());
//				System.out.println(inst);
				String ans="";
				String ans2;
				String binary3;
				int leng;
				int valtwo;
				int val;
				Operand op_1,op_2,op_dest;
//				System.out.println(Integer.toBinaryString(instructionsList.indexOf(inst.getOperationType())));
				System.out.println(inst.getOperationType());
				String binary = Integer.toBinaryString(instructionsList.indexOf(inst.getOperationType()));
//				System.out.println(binary);
				String code=String.format("%5s", binary).replace(' ', '0');
//				System.out.println(code);
				ans+=code;
//				System.out.println(ans);
				int opCode = Integer.parseInt(ans, 2);
//				System.out.println(opCode);
				int pc = inst.getProgramCounter();
				if (opCode <= 20 && opCode % 2 == 0) {
					// R3 Type
//					ans += 	String.format("%5s", Integer.toBinaryString(ParsedProgram.symtab.get(inst.getSourceOperand1().getLabelValue()))).replace(' ', '0');

					op_1=inst.getSourceOperand1();
					op_2=inst.getSourceOperand2();
					op_dest=inst.getDestinationOperand();

					valtwo = op_1.getValue();
					binary3=Integer.toBinaryString(valtwo);
					ans2 = String.format("%5s", binary3).replace(' ', '0');
					ans+=ans2;
					valtwo=op_2.getValue();
					binary3=Integer.toBinaryString(valtwo);
					ans2 = String.format("%5s", binary3).replace(' ', '0');
					ans+=ans2;
					valtwo=op_dest.getValue();
					binary3=Integer.toBinaryString(valtwo);
					ans2 = String.format("%5s", binary3).replace(' ', '0');
					ans+=ans2;
					leng=ans.length();
					for(int i=0;i<32-leng;i++)
					{
						ans+="0";
					}


				}
				else if (opCode == 24) {
					// RI Type
					for(int i=0;i<5;i++)
					{
						ans+="0";
					}
					op_dest=inst.getDestinationOperand();
					valtwo=ParsedProgram.symtab.get(op_dest.getLabelValue());
					binary3=Integer.toBinaryString(valtwo);
					valtwo=Integer.parseInt(binary3,2)-pc;
					binary3=Integer.toBinaryString(valtwo);
					ans2=String.format("%22s", binary3).replace(' ', '0');
					ans2=ans2.substring(ans2.length()-22);
					//System.out.println("valtwo:" +valtwo);

					ans+=ans2;
//					System.out.println("ans2len: "+ans.length());

				}
				else if (opCode == 29) {
					leng=ans.length();
					for(int i=0;i<27;i++)
					{
						ans+="0";
					}

//					ans += toBinaryOfSpecificPrecision(0, 27);
				}
				else {
					// R2I Type
					if (opCode >= 25 && opCode <= 28) {
//						for(int i=0;i<10;i++)
//						{
//							ans+="0";
//						}
						op_1=inst.getSourceOperand1();
						op_2=inst.getSourceOperand2();
						op_dest=inst.getDestinationOperand();

						val=op_1.getValue();
						binary3=Integer.toBinaryString(val);
						ans2 = String.format("%5s", binary3).replace(' ', '0');
						ans+=ans2;
						val=op_2.getValue();
						binary3=Integer.toBinaryString(val);
						ans2 = String.format("%5s", binary3).replace(' ', '0');
						ans+=ans2;



						valtwo=ParsedProgram.symtab.get(op_dest.getLabelValue());
						binary3=Integer.toBinaryString(valtwo);
						valtwo=Integer.parseInt(binary3,2)-pc;
						binary3=Integer.toBinaryString(valtwo);
						ans2=String.format("%17s", binary3).replace(' ', '0');
						ans2=ans2.substring(ans2.length()-17);

						ans+=ans2;
						//System.out.println("ans3: "+ans2);

					}
					else {
						Operand op1,op2,opdest;
						op1=inst.getSourceOperand1();
						op2=inst.getSourceOperand2();
						opdest=inst.getDestinationOperand();
//						int val=ParsedProgram.data.get(op2.getValue()+op1.getValue());
						String binary2;


						//For op1,dest,op2


						val=op1.getValue();
						binary2=Integer.toBinaryString(val);
						ans2 = String.format("%5s", binary2).replace(' ', '0');
						ans+=ans2;
						val=opdest.getValue();
						binary2=Integer.toBinaryString(val);
						ans2 = String.format("%5s", binary2).replace(' ', '0');
						ans+=ans2;
						ans+="000000000000";
						val=op2.getValue();
						binary2=Integer.toBinaryString(val);
						ans2 = String.format("%5s", binary2).replace(' ', '0');
						ans+=ans2;



					}
				}
				int instInteger = (int) Long.parseLong(ans, 2);
//				System.out.println("ans: "+ans);
//				System.out.println(instInteger);
				byte[] instBinary = ByteBuffer.allocate(4).putInt(instInteger).array();
				bfile.write(instBinary);

			}
			bfile.close();
		}catch(IOException e) {
		e.printStackTrace();
	}
	}
	
}
